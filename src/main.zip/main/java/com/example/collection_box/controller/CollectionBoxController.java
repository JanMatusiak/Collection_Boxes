package com.example.collection_box.controller;

import com.example.collection_box.entity.CollectionBox;
import com.example.collection_box.service.CollectionBoxService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;

@RestController
@RequestMapping ("/boxes")
public class CollectionBoxController {
    private final CollectionBoxService boxService;

    public CollectionBoxController(CollectionBoxService boxService){
        this.boxService = boxService;
    }

    @PostMapping
    public ResponseEntity<CollectionBox> createBox(){
        CollectionBox box = boxService.createBox();
        return ResponseEntity.status(HttpStatus.CREATED).body(box);
    }

    @GetMapping
    public ResponseEntity<List<CollectionBox>> listBoxes(
            @RequestParam(name = "onlyEmpty", defaultValue = "false") boolean onlyEmpty){
        List<CollectionBox> boxes = boxService.listBoxes(onlyEmpty);
        return ResponseEntity.ok(boxes);
    }

    @PostMapping
    public ResponseEntity<CollectionBox> assignToEvent(@PathVariable("id") Long boxID,
                                                       @RequestParam("event") Long eventID){

        CollectionBox update = boxService.assignToEvent(boxID, eventID);
        return ResponseEntity.ok(update);
    }

    @PostMapping("/{id}/money")
    public ResponseEntity<CollectionBox> addMoney(@PathVariable("id") Long boxID,
                                                  @RequestParam("amount") BigDecimal amount,
                                                  @RequestParam("currency") String currency){
        CollectionBox update = boxService.addMoney(boxID, amount, currency);
        return ResponseEntity.ok(update);
    }

    @PostMapping("/{id}/empty")
    public ResponseEntity<Void> empty(@PathVariable("id") Long boxID){
        boxService.empty(boxID);
        return ResponseEntity.noContent().build();
    }

}
